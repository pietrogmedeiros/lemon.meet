function m(){const e=window.location.href;return e.includes("meet.google.com")?"google_meet":e.includes("zoom.us")?"zoom":"teams"}function g(){const e="google_meet",n=window.location.href,t=!!document.querySelector('[data-call-ended="false"]')||!!document.querySelector('[jsname="CQylAd"]')||!!document.querySelector('[data-tooltip="Leave call"]')||!!document.querySelector('[aria-label*="Leave"]')||!!document.querySelector("div[data-allocation-index]"),o=document.querySelector("[data-meeting-title]")||document.querySelector("c-wiz[data-meeting-title]"),c=n.match(/meet\.google\.com\/([a-z]{3}-[a-z]{4}-[a-z]{3})/),l=(o==null?void 0:o.getAttribute("data-meeting-title"))||(c?`Reunião ${c[1]}`:"Reunião Google Meet"),r=document.querySelectorAll("[data-allocation-index]").length||document.querySelectorAll('[jsname="cGMI2b"]').length||1;return{inMeeting:t,title:l,meetLink:n,platform:e,participantsCount:r}}function p(){var r,a;const e="zoom",n=window.location.href,t=!!document.querySelector(".meeting-app")||!!document.querySelector("#wc-container-right")||!!document.querySelector('[aria-label="Leave"]'),o=document.querySelector(".meeting-info-header__meeting-topic"),c=((r=o==null?void 0:o.textContent)==null?void 0:r.trim())||"Reunião Zoom",l=parseInt(((a=document.querySelector(".participants-header__count"))==null?void 0:a.textContent)||"1")||1;return{inMeeting:t,title:c,meetLink:n,platform:e,participantsCount:l}}function f(){var r,a;const e="teams",n=window.location.href,t=!!document.querySelector('[data-tid="calling-screen"]')||!!document.querySelector('[id="hangup-button"]'),o=document.querySelector('[data-tid="meeting-title"], .ts-calling-screen-title'),c=((r=o==null?void 0:o.textContent)==null?void 0:r.trim())||"Reunião Teams",l=parseInt(((a=document.querySelector('[data-tid="roster-count"]'))==null?void 0:a.textContent)||"1")||1;return{inMeeting:t,title:c,meetLink:n,platform:e,participantsCount:l}}function y(){const e=m();return e==="google_meet"?g():e==="zoom"?p():f()}let i=null;function h(e){if(i)return;i=document.createElement("div"),i.id="lemon-meet-btn",i.innerHTML=`
    <div style="
      position: fixed;
      bottom: 80px;
      right: 24px;
      z-index: 999999;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 8px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    ">
      <div id="lemon-meet-badge" style="
        background: #2D5A27;
        color: white;
        font-size: 12px;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 999px;
        white-space: nowrap;
        display: none;
      ">● Gravando…</div>
      <button id="lemon-meet-toggle" style="
        background: #2D5A27;
        border: none;
        border-radius: 50%;
        width: 48px;
        height: 48px;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.15s;
      " title="Lemon.meet — gravar reunião">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFD700" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"/>
          <circle cx="12" cy="12" r="3" fill="#FFD700"/>
        </svg>
      </button>
    </div>
  `,document.body.appendChild(i),document.getElementById("lemon-meet-toggle").addEventListener("click",()=>{try{chrome.runtime.sendMessage({type:"TOGGLE_RECORDING"})}catch{}})}function x(){i==null||i.remove(),i=null}function d(e){const n=document.getElementById("lemon-meet-badge"),t=document.getElementById("lemon-meet-toggle");!n||!t||(e==="recording"?(n.style.display="block",n.textContent="● Gravando…",t.style.background="#DC3545",t.style.opacity="1",t.disabled=!1,t.title="Lemon.meet — parar gravação",t.innerHTML='<svg width="22" height="22" viewBox="0 0 24 24" fill="white"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>'):e==="loading"?(n.style.display="block",n.textContent="Processando…",t.style.background="#2D5A27",t.style.opacity="0.7",t.disabled=!0,t.title="Lemon.meet — processando",t.innerHTML=`
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFD700" stroke-width="2.5" stroke-linecap="round">
        <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83">
          <animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="0.8s" repeatCount="indefinite"/>
        </path>
      </svg>`):(n.style.display="none",t.style.background="#2D5A27",t.style.opacity="1",t.disabled=!1,t.title="Lemon.meet — gravar reunião",t.innerHTML='<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFD700" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3" fill="#FFD700"/></svg>'))}chrome.runtime.onMessage.addListener(e=>{if(e.type==="STATE_UPDATE"){const n=e.state;d(n==="recording"?"recording":n==="requesting"||n==="stopping"||n==="processing"?"loading":"idle")}});let s=!1;function u(){const e=y();if(e.inMeeting&&!s){s=!0;try{chrome.runtime.sendMessage({type:"MEETING_DETECTED",...e})}catch{}h()}if(!e.inMeeting&&s){s=!1;try{chrome.runtime.sendMessage({type:"MEETING_ENDED"})}catch{}x()}}setInterval(u,2e3);u();
