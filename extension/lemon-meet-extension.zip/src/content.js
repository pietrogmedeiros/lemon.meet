function s(){const e=window.location.href;return e.includes("meet.google.com")?"google_meet":e.includes("zoom.us")?"zoom":"teams"}function m(){const e="google_meet",t=window.location.href,n=!!document.querySelector('[data-call-ended="false"]')||!!document.querySelector('[jsname="CQylAd"]')||!!document.querySelector('[data-tooltip="Leave call"]')||!!document.querySelector('[aria-label*="Leave"]')||!!document.querySelector("div[data-allocation-index]"),o=document.querySelector("[data-meeting-title]")||document.querySelector("c-wiz[data-meeting-title]"),c=t.match(/meet\.google\.com\/([a-z]{3}-[a-z]{4}-[a-z]{3})/),a=(o==null?void 0:o.getAttribute("data-meeting-title"))||(c?`Reunião ${c[1]}`:"Reunião Google Meet"),r=document.querySelectorAll("[data-allocation-index]").length||document.querySelectorAll('[jsname="cGMI2b"]').length||1;return{inMeeting:n,title:a,meetLink:t,platform:e,participantsCount:r}}function g(){var r,l;const e="zoom",t=window.location.href,n=!!document.querySelector(".meeting-app")||!!document.querySelector("#wc-container-right")||!!document.querySelector('[aria-label="Leave"]'),o=document.querySelector(".meeting-info-header__meeting-topic"),c=((r=o==null?void 0:o.textContent)==null?void 0:r.trim())||"Reunião Zoom",a=parseInt(((l=document.querySelector(".participants-header__count"))==null?void 0:l.textContent)||"1")||1;return{inMeeting:n,title:c,meetLink:t,platform:e,participantsCount:a}}function p(){var r,l;const e="teams",t=window.location.href,n=!!document.querySelector('[data-tid="calling-screen"]')||!!document.querySelector('[id="hangup-button"]'),o=document.querySelector('[data-tid="meeting-title"], .ts-calling-screen-title'),c=((r=o==null?void 0:o.textContent)==null?void 0:r.trim())||"Reunião Teams",a=parseInt(((l=document.querySelector('[data-tid="roster-count"]'))==null?void 0:l.textContent)||"1")||1;return{inMeeting:n,title:c,meetLink:t,platform:e,participantsCount:a}}function f(){const e=s();return e==="google_meet"?m():e==="zoom"?g():p()}let i=null;function y(e){if(i)return;i=document.createElement("div"),i.id="lemon-meet-btn",i.innerHTML=`
    <div style="
      position: fixed;
      bottom: 80px;
      right: 24px;
      z-index: 999999;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 8px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    ">
      <div id="lemon-meet-badge" style="
        background: #2D5A27;
        color: white;
        font-size: 12px;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 999px;
        white-space: nowrap;
        display: none;
      ">● Gravando…</div>
      <button id="lemon-meet-toggle" style="
        background: #2D5A27;
        border: none;
        border-radius: 50%;
        width: 48px;
        height: 48px;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.15s;
      " title="Lemon.meet — gravar reunião">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFD700" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"/>
          <circle cx="12" cy="12" r="3" fill="#FFD700"/>
        </svg>
      </button>
    </div>
  `,document.body.appendChild(i),document.getElementById("lemon-meet-toggle").addEventListener("click",()=>{try{chrome.runtime.sendMessage({type:"OPEN_POPUP"})}catch{}})}function h(){i==null||i.remove(),i=null}function x(e){const t=document.getElementById("lemon-meet-badge"),n=document.getElementById("lemon-meet-toggle");!t||!n||(e?(t.style.display="block",n.style.background="#DC3545",n.title="Lemon.meet — parar gravação"):(t.style.display="none",n.style.background="#2D5A27",n.title="Lemon.meet — gravar reunião"))}chrome.runtime.onMessage.addListener(e=>{e.type==="STATE_UPDATE"&&x(e.state==="recording")});let d=!1;function u(){const e=f();if(e.inMeeting&&!d){d=!0;try{chrome.runtime.sendMessage({type:"MEETING_DETECTED",...e})}catch{}y()}if(!e.inMeeting&&d){d=!1;try{chrome.runtime.sendMessage({type:"MEETING_ENDED"})}catch{}h()}}setInterval(u,2e3);u();
